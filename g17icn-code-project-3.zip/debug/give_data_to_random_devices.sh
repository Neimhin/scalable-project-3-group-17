curl -X GET "http://localhost:34000/give_data_to_random_device?data_name=/foo/bar&data=42"
