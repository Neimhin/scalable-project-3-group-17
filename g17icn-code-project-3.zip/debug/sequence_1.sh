# contributors: NROBINSO
bash debug/give_data_to_random_devices.sh
bash debug/set_desire_for_all.sh
bash debug/cache.sh
