curl http://localhost:34000/debug/pit
