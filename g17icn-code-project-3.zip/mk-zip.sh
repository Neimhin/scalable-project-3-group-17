#!/bin/bash
zip -r g17icn-code-project-3.zip src/* requirements.txt mk-zip.sh debug/* 
