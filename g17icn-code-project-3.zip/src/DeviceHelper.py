'''
Helper class for device class
'''

class DeviceHeler:
    pass
